/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Mahasiswa;
import View.FormMahasiswa;

public class MahasiswaController {
    private Mahasiswa mhs;
    private FormMahasiswa form;

    public MahasiswaController(FormMahasiswa form) {
        this.form = form;
    }
    
    public void proses(){
        mhs = new Mahasiswa();
        mhs.setNobp(form.getTextnobp().getText());
        mhs.setNama(form.getTextnama().getText());
        mhs.setQuiz(Double.parseDouble(form.getTextquiz().getText()));
         mhs.setUts(Double.parseDouble(form.getTextuts().getText()));
         mhs.setUas(Double.parseDouble(form.getTextuas().getText()));
         
         mhs.setRata((mhs.getQuiz()+mhs.getUts()+mhs.getUas())/3);
         
         if(mhs.getRata() >= 75){
             mhs.setKompetensi("selamat angku lulus");
         }else{
             mhs.setKompetensi("angku baraja baliak");
         }
         
         form.getTexthasil().setText("=============informasi nilai mahasiswa============\n"
                                     +"No BP :" +mhs.getNobp()+"\n"
                                     +"Nama  :" +mhs.getNama()+"\n"
                                     +"Quiz  :" +mhs.getQuiz()+"\n"
                                     +"UTS   :" +mhs.getUts()+"\n"
                                     +"UAS   :" +mhs.getUas()+"\n"
                                     +"RATA   :" +mhs.getRata()+"\n"
                                     +"kompetensi:" +mhs.getKompetensi()+"\n"
                                     +"=======================================");
         
    }
    public void reset(){
        form.getTextnobp().setText("");
        form.getTextnama().setText("");
        form.getTextquiz().setText("");
        form.getTextuts().setText("");
        form.getTextuas().setText("");
    }
}
