/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Transaksi;
import Model.membermodel;
import View.MemberView;
import View.fromTransaksi;
import java.util.List;

/**
 *
 * @author User
 */
public class transaksiController {
    
    private Transaksi trans;
    private fromTransaksi form;
    MemberView frame_member;
    List<membermodel> list;

    public transaksiController(fromTransaksi form) {
        this.form = form;
    }
    
    public void isiField(int row){
        frame_member.getTextid().setText(list.get(row).getNama());
        frame_member.getCbopket().setSelectedItem(list.get(row).getPaket());
       
        
        
    }
    
    public void proses(int row){
        trans = new Transaksi();
        trans.setId_transaksi(form.getTxtID().getText());
        trans.setNama_jp(frame_member.getTextid().setText(Integer.toString(list.get(row))));
        
        
    }
    
    
}
