/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import DAO.AnggotaDao;
import DAO.AnggotaDaoImpl;
import Model.Anggota;
import View.FromAnggota;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author User
 */
public class AnggotaController {
    private FromAnggota form;
    private AnggotaDao anggotadao;
    private Anggota anggota;
    
    public AnggotaController(FromAnggota form){
        this.form = form;
        anggotadao = new AnggotaDaoImpl();
    }
    
    public void clearForm(){
        form.getTextid().setText("");
        form.getTextnama().setText("");
        form.getTextalamat().setText("");
        
    }
    
    public void tampilData(){
        DefaultTableModel tableModel = (DefaultTableModel)
                form.getTblanggota().getModel();
        tableModel.setRowCount(0);
        List<Anggota> listAnggota = anggotadao.getAllAnggota();
        for(Anggota anggota : listAnggota){
            Object[] data = {anggota.getIdAnggota(),
                             anggota.getNama(),
                             anggota.getAlamat(),
                             anggota.getJenisKelamin()};
            
                             tableModel.addRow(data);
        }
    }
    
    public void getAnggota(){
        int index =form.getTblanggota().getSelectedRow();
        anggota = anggotadao.getAnggota(index);
        if(anggota != null){
            form.getTextid().setText(anggota.getIdAnggota());
            form.getTextnama().setText(anggota.getNama());
            form.getTextalamat().setText(anggota.getAlamat());
            form.getCbojk().setSelectedItem(anggota.getJenisKelamin());
            
        }
    }
    public void save(){
        anggota = new Anggota();
        anggota.setIdAnggota(form.getTextid().getText());
        anggota.setNama(form.getTextnama().getText());
        anggota.setAlamat(form.getTextalamat().getText());
        anggota.setJenisKelamin(form.getCbojk().getSelectedItem().toString());
        anggotadao.save(anggota);
        JOptionPane.showMessageDialog(form, "entri data OK");

    }
    public void delete(){
        int index = form.getTblanggota().getSelectedRow();
        anggotadao.delete(index);
         JOptionPane.showMessageDialog(form, "delete data OK");
        
    }
    
    public void update(){
        int index = form.getTblanggota().getSelectedRow();
        anggota.setIdAnggota(form.getTextid().getText());
        anggota.setNama(form.getTextnama().getText());
        anggota.setAlamat(form.getTextalamat().getText());
        anggota.setJenisKelamin(form.getCbojk().getSelectedItem().toString());
        anggotadao.update(index, anggota);
         JOptionPane.showMessageDialog(form, "update data OK");
    }
}
