/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import DAO.memberDao;
import DAO.memberDaoImpl;
import Model.membermodel;
import Model.membertable;
import View.MemberView;
import java.util.List;
import javax.swing.JOptionPane;


/**
 *
 * @author User
 */
public class MemberController {
    MemberView frame_member;
    memberDao implement_member;
    List<membermodel> list_member;

    public MemberController(MemberView frame_member) {
        this.frame_member = frame_member;
        implement_member = new memberDaoImpl();
        list_member = implement_member.getAll();
    }
    
    public void reset(){
        frame_member.getTextid().setText("");
        frame_member.getTxtnamaplg().setText("");
        frame_member.getTxtnotelp().setText("");
        frame_member.getTxtareaalmt().setText("");
        frame_member.getCbopket().setSelectedItem("--pilih paket--");
        frame_member.getTxtcaridata().setText("");       
        
    }
    public void isiTable(){
        list_member = implement_member.getAll();
        membertable tmb = new membertable(list_member);
        frame_member.getTable1().setModel(tmb);
    }
    
    public void isiField(int row){
        frame_member.getTextid().setText(Integer.toString(list_member.get(row).getId()));
        frame_member.getTxtnamaplg().setText(list_member.get(row).getNama());
        frame_member.getTxtnotelp().setText(list_member.get(row).getNoTlp());
        frame_member.getTxtareaalmt().setText(list_member.get(row).getAlamat());
        frame_member.getCbopket().setSelectedItem(list_member.get(row).getPaket());
        
    }
    public void insert(){
        if(!frame_member.getTxtnamaplg().getText().trim().isEmpty() & !frame_member.getTxtnotelp().getText().trim().isEmpty()
                & !frame_member.getTxtareaalmt().getText().trim().isEmpty()){
            membermodel b = new membermodel();
            b.setNama(frame_member.getTxtnamaplg().getText());
            b.setNoTlp(frame_member.getTxtnotelp().getText());
            b.setAlamat(frame_member.getTxtareaalmt().getText());
            b.setPaket(frame_member.getCbopket().getSelectedItem().toString());
            
            implement_member.insert(b);
            JOptionPane.showMessageDialog(null, "Data Berhasil Disimpan");   
        }else
            JOptionPane.showMessageDialog(frame_member, "Data tidak boleh kosong");
        
    }
    public void update(){
        if(!frame_member.getTextid().getText().trim().isEmpty()){
            membermodel b = new membermodel();
            b.setNama(frame_member.getTxtnamaplg().getText());
            b.setNoTlp(frame_member.getTxtnotelp().getText());
            b.setAlamat(frame_member.getTxtareaalmt().getText());
            b.setPaket(frame_member.getCbopket().getSelectedItem().toString());
            b.setId(Integer.parseInt(frame_member.getTextid().getText()));
            
            implement_member.update(b);
            JOptionPane.showMessageDialog(null, "Data Berhasil Diupdate");
        }else
            JOptionPane.showMessageDialog(frame_member, "silahkan pilih data");
    }
    
    public void delete(){
        if(!frame_member.getTextid().getText().trim().isEmpty()){
            int id =Integer.parseInt(frame_member.getTextid().getText());
            implement_member.delete(id);
        }
    }
    public void isiTableCariNama(){
        list_member = implement_member.getCariNama(frame_member.getTxtcaridata().getText());
        membertable tmb =new membertable(list_member);
        frame_member.getTable1().setModel(tmb);
    }
    public void cariNama(){
        if(!frame_member.getTxtcaridata().getText().trim().isEmpty()){
            implement_member.getCariNama(frame_member.getTxtcaridata().getText());
            isiTableCariNama();
        }else{
            JOptionPane.showMessageDialog(frame_member, "Silahkan Pilih data");
        }
    }
    
}
