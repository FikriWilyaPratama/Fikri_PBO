/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Buku;
import View.formBuku;
import DAO.bukuDao;
import DAO.bukuDaoImpl;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class bukuController {
    private formBuku form;
    private bukuDao bukudao;
    private Buku buku;
    
    public bukuController(formBuku form){
        this.form = form;
        bukudao = new bukuDaoImpl();
    }
    
    public void clear(){
        form.getTxtKodeBuku().setText("");
        form.getTxtJudulBuku().setText("");
        form.getTxtPengarang().setText("");
        form.getTxtTahunTerbit().setText("");
    }
    
    public void display(){
        DefaultTableModel tableModel = (DefaultTableModel)
                form.getTblBuku().getModel();
        tableModel.setRowCount(0);
        List<Buku> listBuku = bukudao.getAllBuku();
        for (Buku buku : listBuku){
            Object[] data = {buku.getKodeBuku(),
                            buku.getJudul(),
                            buku.getPengarang(),
                            buku.getThnTerbit()};
            tableModel.addRow(data);
        }
    }
    
    public void getBuku(){
        int index = form.getTblBuku().getSelectedRow();
        buku = bukudao.getBuku(index);
        if(buku != null){
            form.getTxtKodeBuku().setText(buku.getKodeBuku());
            form.getTxtJudulBuku().setText(buku.getJudul());
            form.getTxtPengarang().setText(buku.getPengarang());
            form.getTxtTahunTerbit().setText(buku.getThnTerbit());
        }
    }
    
    public void save(){
        buku = new Buku();
        buku.setKodeBuku(form.getTxtKodeBuku().getText());
        buku.setJudul(form.getTxtJudulBuku().getText());
        buku.setPengarang(form.getTxtPengarang().getText());
        buku.setThnTerbit(form.getTxtTahunTerbit().getText());
        bukudao.save(buku);
        JOptionPane.showMessageDialog(form, "Entri Data OK!");
    }
    
    public void delete(){
        int index = form.getTblBuku().getSelectedRow();
        bukudao.delete(index);
        JOptionPane.showMessageDialog(form, "Hapus Data OK!");
    }
    
    public void update(){
        int index = form.getTblBuku().getSelectedRow();
        buku.setKodeBuku(form.getTxtKodeBuku().getText());
        buku.setJudul(form.getTxtJudulBuku().getText());
        buku.setPengarang(form.getTxtPengarang().getText());
        buku.setThnTerbit(form.getTxtTahunTerbit().getText());
        bukudao.update(index, buku);
        JOptionPane.showMessageDialog(form, "Update Data OK!");
    }
}