/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import DAO.AnggotaDao;
import DAO.AnggotaDaoImpl;
import DAO.bukuDao;
import DAO.bukuDaoImpl;
import DAO.peminjamanDao;
import DAO.peminjamanDaoImpl;
import Model.Anggota;
import Model.Buku;
import Model.Peminjaman;
import View.formPeminjaman;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author User
 */
public class peminjamanController {
    
    private formPeminjaman form;
    private peminjamanDao dao;
    private Peminjaman peminjaman;
    private bukuDao buku;
    private AnggotaDao anggota;

    public peminjamanController(formPeminjaman form) {
        this.form = form;
        anggota = new AnggotaDaoImpl();
        buku = new bukuDaoImpl();
        dao = new peminjamanDaoImpl();
        
    }
    
    public void setCbxNoBp(){
        form.getjCbonobp().removeAllItems();
        List<Anggota> list = anggota.getAllAnggota();
        for(Anggota anggota : list){
            form.getjCbonobp().addItem(anggota.getIdAnggota()
                    +"-"+anggota.getNama());     
        }   
    }
    public void setCbxBuku(){
        form.getjCbokdbuku().removeAllItems();
        List<Buku> list = buku.getAllBuku();
        for(Buku buku : list){
            form.getjCbokdbuku().addItem(buku.getKodeBuku());
        }    
    }
    
    public void clear(){
        form.getjTxtkdpinjam();
        form.getjTxttglpinjam().setText("");
        form.getjTxtkembali().setText("");
    }
    
    public void tampil(){
        DefaultTableModel tableModel = (DefaultTableModel)
                form.getjTable1().getModel();
        tableModel.setRowCount(0);
        List<Peminjaman> listpeminjaman = dao.getAllAnggota();
        for(Peminjaman peminjaman : listpeminjaman){
            Object [] data = {
            peminjaman.getNoBp(),
            peminjaman.getBuku(),
            peminjaman.getKdpinjam(),
            peminjaman.getTglpnjm(),
            peminjaman.getTglkmbl()
        };
          tableModel.addRow(data);
        }
    }
    
    public void getPeminjaman(){
        int index = form.getjTable1().getSelectedRow();
        peminjaman = dao.getAnggota(index);
        if(peminjaman != null){
            List<Anggota> listAnggota = anggota.getAllAnggota();
            for(Anggota anggota : listAnggota){
            if(peminjaman.getNoBp()==anggota.getIdAnggota()){
                form.getjCbonobp().setSelectedItem(anggota.getIdAnggota()
                        +"-"+anggota.getNama());
            break;
        }
    }
            form.getjCbokdbuku().setSelectedItem(peminjaman.getBuku());
            form.getjTxttglpinjam().setText(peminjaman.getTglpnjm());
            form.getjTxtkembali().setText(peminjaman.getTglkmbl());
            form.getjTxtkdpinjam().setText(peminjaman.getKdpinjam());
}
    }
    
    public void simpan(){
        peminjaman = new Peminjaman();
        peminjaman.setNoBp(form.getjCbonobp().getSelectedItem().toString().split("-")[0]);
        peminjaman.setBuku(form.getjCbokdbuku().getSelectedItem().toString());
        peminjaman.setKdpinjam(form.getjTxtkdpinjam().getText());
        peminjaman.setTglpnjm(form.getjTxttglpinjam().getText());
        peminjaman.setTglkmbl(form.getjTxtkembali().getText());
        dao.save(peminjaman);
        JOptionPane.showMessageDialog(form,"entri data ok");
        
    }
    public void delete(){
        int index = form.getjTable1().getSelectedRow();
        dao.delete(index);
        JOptionPane.showMessageDialog(form, "delete data ok");
    }
    
    public void update(){
        int index = form.getjTable1().getSelectedRow();
        peminjaman = dao.getAnggota(index);
        peminjaman.setNoBp(form.getjCbonobp().getSelectedItem().toString().split("-")[0]);
        peminjaman.setBuku(form.getjCbokdbuku().getSelectedItem().toString());
        peminjaman.setKdpinjam(form.getjTxtkdpinjam().getText());
        peminjaman.setTglpnjm(form.getjTxttglpinjam().getText());
        peminjaman.setTglkmbl(form.getjTxtkembali().getText());
        dao.update(index, peminjaman);
        JOptionPane.showMessageDialog(form, "update data ok");
        
      
    }
}