/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UTS2201091017;



/**
 *
 * @author User
 */
public class Mobil1 {
    
    private String noSIM;
    private String tahunProduksi;
    private String tipeTransmisi;
    private String kapasitasMesin;
    private String warna;
    private static int dataCount;
    double harga;
    int stok;
    double total;
    double bayar;

     public Mobil1() {
        dataCount++;
    }

    public static int getDataCount() {
        return dataCount;
    }

    public void setNama(String noSIM) {
        this.noSIM = noSIM;
    }

    public String getNama() {
        return noSIM;
    }

    public void setAlamat(String tahunProduksi) {
        this.tahunProduksi = tahunProduksi;
    }

    public String getAlamat() {
        return tahunProduksi;
    }

    public void setTelp(String tipeTransmisi) {
        this.tipeTransmisi = tipeTransmisi;
    }

    public String getTelp() {
        return tipeTransmisi;
    }

    public void setEmail(String kapasitasMesin) {
        this.kapasitasMesin = kapasitasMesin;
    }

    public String getEmail() {
        return kapasitasMesin;
    }
    
    public void setWarna(String warna) {
        this.warna = warna;
    }

    public String getWarna() {
        return warna;
    }
    
     double diskon(){
       if(total>=100000){
            bayar=total-(total*0.1);
       }else{
             bayar=total-0;
       }
       System.out.println("total bayar =" +bayar);
       return bayar;
   }
    
    
}

