/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UTS2201091017;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class exMobil {
   public static void main(String[] args) {
        Scanner sc = new Scanner (System.in);
        Mobil1 data[] = new Mobil1[100];
        int pil=0;
        int index=0;
        double harga;
     int stok;
    double total;
    double bayar;
        while (pil != 5){
            
            System.out.println("\n1.Sedan");
            System.out.println("2.MVP");
            System.out.println("3.CityCar");
             System.out.println("Input pilihan  :");
            pil = sc.nextInt();
            
            
              switch(pil){
                  
                  case 1:
                      System.out.println("Memasukkan data");
                    Mobil1 b = new Mobil1();
                  System.out.print("nosim  :");
                    b.setNama(sc.next());
                
                    System.out.print("tahunProduksi  :");
                    b.setAlamat(sc.next());
                    
                    System.out.print("tipeTransmisi  :");
                    b.setTelp(sc.next());
                    
                    System.out.print("kapasitasMesin  :");
                    b.setEmail(sc.next());
                      
                    System.out.print("warna  :");
                    b.setWarna(sc.next());
                      
                    b.diskon();

        
              }
}
   }
}
