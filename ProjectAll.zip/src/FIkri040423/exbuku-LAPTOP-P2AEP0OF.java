/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FIkri040423;

/**
 *
 * @author User
 */
public class exbuku {
    public static void main(String[] args) {
        
        classbuku buku1 = new classbuku("B472","jembatan ilmu","gramedia","2000",50000,6);
        buku1.cekbarang();
        
      classbuku buku2 = new classbuku("B665","banteng","gramedia","2001",70000,6);
       buku2.cekbarang();
//        classbuku buku3 = new classbuku("B345","kitab pink","gramedia","2002",40000,6);
//        classbuku buku4 = new classbuku("B556","surga neraka","gramedia","2003",85000,6);
//        classbuku buku5 = new classbuku("B795","PDIP","gramedia","2004",45000,6);
//        classbuku buku6 = new classbuku("B132","HArry Potter","gramedia","2004",20000,6);
//        classbuku buku7 = new classbuku("B980","pARTAI","gramedia","2005",65000,6);
          
        
      
        
    }
    
}
