/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FIkri040423;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class classbuku {
    String kode ;
    String judul;
    String penerbit;
    String tahun;
    double harga;
    int stok;
    double total;
    double bayar;
    
   classbuku(String kode, String judul, String penerbit, String tahun,double harga,  int stok)
        {
             this.kode= kode;
             this.judul=judul;
             this.penerbit=penerbit;
             this.tahun=tahun;
             this.harga=harga;
             this.stok=stok;
             
             System.out.println("kode= "+this.kode);
             System.out.println("judul= "+this.judul);
             System.out.println("penerbit= "+this.penerbit);
             System.out.println("tahun= "+this.tahun);
             System.out.println("harga= "+this.harga);
             System.out.println("stok "+this.stok +"\n");       
        }
   
   void cekbarang(){
       if(stok>0){
           System.out.println("Transaksi diproses...");
           System.out.println("stok saat ini= " +this.stok);
           Scanner sc = new Scanner(System.in);
           System.out.println("masukkan jmlh buku..=");
           int jmlbeli=sc.nextInt();
           pembelian(jmlbeli);
           diskon();
           
       }else{
           
           System.out.println("trnasaksi dibatalkan...");
       }
   }
   
   double pembelian(int beli){
       
       total=harga*beli;
       System.out.println("total hargaa= " + total);
       return total;
       
   }
   
   double diskon(){
       if(total>=100000){
            bayar=total-(total*0.1);
       }else{
             bayar=total-0;
       }
       System.out.println("total bayar =" +bayar);
       return bayar;
   }
        
}
