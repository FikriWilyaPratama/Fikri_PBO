/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UTS2;

/**
 *
 * @author User
 */
public class rumah {
    
     protected String no_rumah;
    protected String tipebangunan;
    protected int panjang;
     protected int lebar;
    public double total;
     public double bayar;
      public double luas;
       public double harga;
    public rumah() {
        
        
        
    }

    public rumah(String no_rumah, String tipebangunan, int panjang, int lebar) {
        this.no_rumah = no_rumah;
        this.tipebangunan = tipebangunan;
        this.panjang = panjang;
        this.lebar = lebar;
       
        
        
        System.out.println("no rumah :"+ this.no_rumah);
        System.out.println("tipe bangunan :"+ this.tipebangunan);
        System.out.println("pjg :"+ this.panjang);
        System.out.println("lbr :"+ this.lebar);
  
    }

    public String getNo_rumah() {
        return no_rumah;
    }

    public String getTipebangunan() {
        return tipebangunan;
    }

    public int getPanjang() {
        return panjang;
    }

    public int getLebar() {
        return lebar;
    }


    public void setNo_rumah(String no_rumah) {
        this.no_rumah = no_rumah;
    }

    public void setTipebangunan(String tipebangunan) {
        this.tipebangunan = tipebangunan;
    }

    public void setPanjang(int panjang) {
        this.panjang = panjang;
    }

    public void setLebar(int lebar) {
        this.lebar = lebar;
    }

  public double luasTanah(){
        
        return luas;
    }
    
       public double harga(){
      
        return harga;
     
    
}
}
