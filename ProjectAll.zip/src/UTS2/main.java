/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UTS2;
import java.util.Scanner;
/**
 *
 * @author User
 */
public class main {
    public static void main(String[] args) {
  
        Scanner sc = new Scanner(System.in);
        System.out.println("Tipe mesin :");
        System.out.println("1. minimalis ");
        System.out.println("2. mewah ");
        System.out.println("Pilihan mobil yang mauu:");
        int pil=sc.nextInt();
        
        switch(pil){
            
            case 1:{
                Minimalis erty = new Minimalis();
                System.out.println("luas = "+erty.luasTanah());
                System.out.println("totalharga ="+erty.harga());
             
            }break;
            case 2:{
                Mewah tyu = new Mewah();
                System.out.println("luas = "+tyu.luasTanah() );
                System.out.println("totalharga ="+tyu.harga());
            
            }break;
    }
    }
}

