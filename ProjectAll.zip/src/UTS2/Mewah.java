/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UTS2;

/**
 *
 * @author User
 */
public class Mewah  extends rumah{
    
    public Mewah(){
        super("18","Lantai 1", 15, 10);
    }
    
    public double luasTanah(){
        luas = panjang * lebar;
        return luas;
    }
    
    public double harga(){
        harga = (luas * 50000)+200000;
        return harga;
    }
}