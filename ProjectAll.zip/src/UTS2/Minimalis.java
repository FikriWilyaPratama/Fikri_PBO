/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UTS2;

/**
 *
 * @author User
 */
public class Minimalis  extends rumah{
    
    public Minimalis(){
        super("18","Lantai 1", 9, 7);
    }
    
    public double luasTanah(){
        luas = panjang * lebar;
        return luas;
    }
    
    public double harga(){
        harga = (luas * 20000)+100000;
        return harga;
    }
}
    

