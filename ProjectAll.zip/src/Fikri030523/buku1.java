/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Fikri030523;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class buku1 {
     public static void main(String[] args) {
        Scanner sc = new Scanner (System.in);
        BukuAlamat data[] = new BukuAlamat[100];
        int pil=0;
        int index=0;
        while (pil != 5){
            
            System.out.println("\n1.Memasukkan data");
            System.out.println("2.Menghapus data");
            System.out.println("3.Menampilkan seluruh data");
            System.out.println("4.Update data");
            System.out.println("5.Keluar");
            System.out.println("Input pilihan  :");
            pil = sc.nextInt();
            
            
            
            switch(pil){
                
                case 1 :
                    System.out.println("Memasukkan data");
                    BukuAlamat b = new BukuAlamat();
                    
                    System.out.print("Nama  :");
                    b.setNama(sc.next());
                
                    System.out.print("Alamat  :");
                    b.setAlamat(sc.next());
                    
                    System.out.print("Telp  :");
                    b.setTelp(sc.next());
                    
                    System.out.print("Email  :");
                    b.setEmail(sc.next());
                    
                    System.out.println("Entri data ok");
                    data[index]= b;
                    index++;
                    
                    
                    break;
            
            case 2: 
                
                System.out.println("Menghapus data");
                System.out.println("Index yang akan dihapus");
                int index_delete=sc.nextInt();
                System.out.print("Delete nama Ok(pliss enter)");
                data[index_delete].setNama(sc.next());
                 System.out.println("Delete alamat Ok(pliss enter)");
                data[index_delete].setAlamat(sc.nextLine());
                 System.out.print("Delete telp Ok(pliss enter)");
                data[index_delete].setTelp(sc.nextLine());
                 System.out.print("Delete email Ok(pliss enter)");
                data[index_delete].setEmail(sc.nextLine());
                System.out.println("Delete data Ok");
                
                break;
                
            case 3:
                
                System.out.println("Menampilkan seluruh data");
                System.out.println("\nJumlah Data :" +BukuAlamat.getDataCount());
                for( int i=0;i<data.length;i++){
                    
                    System.out.println("\nData ke : " + (i + 1));
                    System.out.println("Nama    :" + data[i].getNama());
                    System.out.println("Alamat   :" + data[i].getAlamat());
                    System.out.println("Telp   :" + data[i].getTelp());
                    System.out.println("Email   :" + data[i].getEmail());
                    if (i+1 == BukuAlamat.getDataCount()){
                        break;
                    }
                    
                }
                break;
                
            case 4 :
                System.out.println("Update data");
                System.out.print("Index yang akan di update");
                int index_update = sc.nextInt();
                
                System.out.print("Nama    :");
                data[index_update].setNama(sc.next());
                System.out.print("Alamat  :");
                data[index_update].setAlamat(sc.next());
                System.out.print("Telp    :");
                data[index_update].setTelp(sc.next());
                System.out.print("Email   :");
                data[index_update].setEmail(sc.next());
                System.out.println("update data Ok");
                
                break;
                      
        }
    
}
    
     }
}
