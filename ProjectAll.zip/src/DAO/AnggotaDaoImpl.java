/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Model.Anggota;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author User
 */
public class AnggotaDaoImpl implements AnggotaDao{
    List<Anggota> data = new ArrayList<>();
    
    public AnggotaDaoImpl(){
        data.add(new Anggota("123456","Dea","padang","perempuan"));
         data.add(new Anggota("94593","Pikir","PKU","laki-laki"));
        
    }

    @Override
    public Anggota save(Anggota anggota) {
      data.add(anggota);
      return anggota;
    }

    @Override
    public Anggota update(int index, Anggota anggota) {
      data.set(index, anggota);
      return anggota;
    }

    @Override
    public Anggota delete(int index) {
      return data.remove(index);
    }

    @Override
    public Anggota getAnggota(int index) {
     return data.get(index);
     
    }

    @Override
    public List<Anggota> getAllAnggota() {
       return data;
    }
    
}
