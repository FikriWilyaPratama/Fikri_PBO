/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Model.Buku;
import java.util.ArrayList;
import java.util.List;

public class bukuDaoImpl implements bukuDao{
    List<Buku> data = new ArrayList<>();

    public bukuDaoImpl() {
        data.add(new Buku("12345","To Kill a Mockingbird","Harper Lee","1960"));
        data.add(new Buku("34532","The Birth of Tragedy","Friedrich Nietzsche","1886"));
    }

    @Override
    public Buku save(Buku buku) {
        data.add(buku);
        return buku;
    }

    @Override
    public Buku update(int index, Buku buku) {
        data.set(index, buku);
        return buku;
    }

    @Override
    public Buku delete(int index) {
        return data.remove(index);
    }

    @Override
    public Buku getBuku(int index) {
        return data.get(index);
    }

    @Override
    public List<Buku> getAllBuku() {
        return data;
    }
    
}
