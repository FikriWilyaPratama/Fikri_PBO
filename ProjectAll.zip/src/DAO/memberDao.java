/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Model.membermodel;
import java.util.List;

/**
 *
 * @author User
 */
public interface memberDao {
    public void insert(membermodel b);
    public void update(membermodel b);
    public void delete(int id);
    
    public List<membermodel> getAll();
    public List<membermodel> getCariNama(String nama);
    
    
    
}
