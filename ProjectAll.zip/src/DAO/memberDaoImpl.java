/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Model.membermodel;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import koneksi.memberkoleksi;

/**
 *
 * @author User
 */
public class memberDaoImpl implements memberDao {
    Connection connection;
    
    final String insert= "INSERT INTO member (nama, no_telpon, alamat, paket) VALUES (?,?,?,?);";
    final String update= "UPDATE member set nama=?, no_telpon=?, alamat=?, paket=? where id=? ;";
    final String delete= "DELETE FROM member where id=?;";
    final String select= "SELECT * FROM member;";
    final String carinama= "SELECT * FROM member where nama like ?";

    public memberDaoImpl() {
        connection = memberkoleksi.connection();
    }

    @Override
    public void insert(membermodel b) {
        PreparedStatement statement = null;
        try{
            statement = (PreparedStatement) connection.prepareStatement(insert);
            statement.setString(1, b.getNama());
            statement.setString(2, b.getNoTlp());
            statement.setString(3, b.getAlamat());
            statement.setString(4, b.getPaket());
            statement.executeUpdate();
            
        }catch (Exception e){
            e.printStackTrace();
        }finally{
            try{
                statement.close();
            }catch (Exception e){
                e.printStackTrace();
            }
        }
        
    }

    @Override
    public void update(membermodel b) {
       PreparedStatement statement = null;
        try{
            statement = (PreparedStatement) connection.prepareStatement(update);
            statement.setString(1, b.getNama());
            statement.setString(2, b.getNoTlp());
            statement.setString(3, b.getAlamat());
            statement.setString(4, b.getPaket());
            statement.setInt(5, b.getId());
            statement.executeUpdate();
            
        }catch (Exception e){
            e.printStackTrace();
        }finally{
            try{
                statement.close();
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }

    @Override
    public void delete(int id) {
        PreparedStatement statement = null;
        try{
            statement = (PreparedStatement) connection.prepareStatement(delete);
           statement.setInt(1, id);
            statement.executeUpdate();
            
        }catch (Exception e){
            e.printStackTrace();
        }finally{
            try{
                statement.close();
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }

    @Override
    public List<membermodel> getAll() {
        List<membermodel> lb = null;
        try{
            lb = new ArrayList<membermodel>();
            Statement st = (Statement) connection.createStatement();
            ResultSet rs = st.executeQuery(select);
            while (rs.next()){
                membermodel b = new membermodel();
                b.setId(rs.getInt("id"));
                b.setNama(rs.getString("nama"));
                b.setNoTlp(rs.getString("no_telpon"));
                b.setAlamat(rs.getString("alamat"));
                b.setPaket(rs.getString("paket"));
                lb.add(b);
            }
        } catch(Exception e){
            Logger.getLogger(memberDao.class.getName()).log(Level.SEVERE,null,e);
        }
        return lb;
    }

    @Override
    public List<membermodel> getCariNama(String nama) {
        List<membermodel> lb = null;
        try{
            lb = new ArrayList<membermodel>();
            PreparedStatement st = (PreparedStatement) connection.prepareStatement(carinama);
            st.setString(1, nama);
            ResultSet rs = st.executeQuery();
            while (rs.next()){
                membermodel b = new membermodel();
                b.setId(rs.getInt("id"));
                b.setNama(rs.getString("nama"));
                b.setNoTlp(rs.getString("no_telpon"));
                b.setAlamat(rs.getString("alamat"));
                b.setPaket(rs.getString("paket"));
                lb.add(b);
            }
        } catch(Exception e){
            Logger.getLogger(memberDao.class.getName()).log(Level.SEVERE,null,e);
        }
        return lb;
       
    }
    
    
    
}
