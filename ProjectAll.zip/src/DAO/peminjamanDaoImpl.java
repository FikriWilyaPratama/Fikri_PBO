/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Model.Peminjaman;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author User
 */
public class peminjamanDaoImpl implements peminjamanDao {
    
     List<Peminjaman> data = new ArrayList<>();
    
    public peminjamanDaoImpl(){
        data.add(new Peminjaman());
         data.add(new Peminjaman());
    
}

    @Override
    public Peminjaman save(Peminjaman peminjaman) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Peminjaman update(int index, Peminjaman peminjaman) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Peminjaman delete(int index) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Peminjaman getAnggota(int index) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Peminjaman> getAllAnggota() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
