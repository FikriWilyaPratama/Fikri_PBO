/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pikir130223;

/**
 *
 * @author User
 */
public class mainclass {
    public static void main(String[] args) {
        LivingThing ref;
        Human huumanobject=new Human();
        huumanobject.walk();
        huumanobject.breath();
    }
    
}
