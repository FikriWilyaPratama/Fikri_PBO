/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author User
 */
public class Peminjaman {
    private String NoBp;
    private String buku;
    private String Kdpinjam;
    private String tglpnjm;
    private String tglkmbl;

    public Peminjaman() {
        
    }

    public String getNoBp() {
        return NoBp;
    }

    public String getBuku() {
        return buku;
    }

    public String getKdpinjam() {
        return Kdpinjam;
    }

    public String getTglpnjm() {
        return tglpnjm;
    }

    public String getTglkmbl() {
        return tglkmbl;
    }

    public void setNoBp(String NoBp) {
        this.NoBp = NoBp;
    }

    public void setBuku(String buku) {
        this.buku = buku;
    }

    public void setKdpinjam(String Kdpinjam) {
        this.Kdpinjam = Kdpinjam;
    }

    public void setTglpnjm(String tglpnjm) {
        this.tglpnjm = tglpnjm;
    }

    public void setTglkmbl(String tglkmbl) {
        this.tglkmbl = tglkmbl;
    }
    
    
    
    
}
