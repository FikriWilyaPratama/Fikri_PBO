
package Model;


public class Mahasiswa {
    private String nobp;
    private String nama;
    private double quiz;
    private double uts;
    private double uas;
    private double rata;
    private String kompetensi;

    public String getNobp() {
        return nobp;
    }

    public String getNama() {
        return nama;
    }

    public double getQuiz() {
        return quiz;
    }

    public double getUts() {
        return uts;
    }

    public double getUas() {
        return uas;
    }

    public double getRata() {
        return rata;
    }

    public String getKompetensi() {
        return kompetensi;
    }

    public void setNobp(String nobp) {
        this.nobp = nobp;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public void setQuiz(double quiz) {
        this.quiz = quiz;
    }

    public void setUts(double uts) {
        this.uts = uts;
    }

    public void setUas(double uas) {
        this.uas = uas;
    }

    public void setRata(double rata) {
        this.rata = rata;
    }

    public void setKompetensi(String kompetensi) {
        this.kompetensi = kompetensi;
    }
    
    
    
           
    
}
