/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

public class Buku {
    private String kodeBuku;
    private String judul;
    private String pengarang;
    private String thnTerbit;

    public Buku() {
    }

    public Buku(String kodeBuku, String judul, String pengarang, String thnTerbit) {
        this.kodeBuku = kodeBuku;
        this.judul = judul;
        this.pengarang = pengarang;
        this.thnTerbit = thnTerbit;
    }

    public String getKodeBuku() {
        return kodeBuku;
    }

    public void setKodeBuku(String kodeBuku) {
        this.kodeBuku = kodeBuku;
    }

    public String getJudul() {
        return judul;
    }

    public void setJudul(String judul) {
        this.judul = judul;
    }

    public String getPengarang() {
        return pengarang;
    }

    public void setPengarang(String pengarang) {
        this.pengarang = pengarang;
    }

    public String getThnTerbit() {
        return thnTerbit;
    }

    public void setThnTerbit(String thnTerbit) {
        this.thnTerbit = thnTerbit;
    }
}