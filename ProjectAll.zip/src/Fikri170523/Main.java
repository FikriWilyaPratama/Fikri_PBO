
package Fikri170523;

import java.util.Scanner;


        
public class Main {
    public static void main(String[] args) {
        double t;
        Scanner sc = new Scanner(System.in);
        System.out.println("Tipe mesin :");
        System.out.println("1. Sedan ");
        System.out.println("2. MVP ");
        System.out.println("3. City Car ");
        System.out.println("Pilihan mobil yang mauu:");
        int pil=sc.nextInt();
        
        switch(pil){
            
            case 1:{
                Sedan vios = new Sedan();
                System.out.println("Harga = "+vios.harga(20) );
                System.out.println("diskon ="+vios.diskon());
                t = vios.harga(20) - vios.diskon();
                System.out.println("total ="+t);
            }break;
            case 2:{
                MVP avanza = new MVP();
                System.out.println("Harga = "+avanza.harga(20) );
                System.out.println("diskon ="+avanza.diskon());
                t = avanza.harga(20) - avanza.diskon();
                System.out.println("total ="+t);
            }break;
            case 3:{
                Citycar yaris = new Citycar();
                System.out.println("Harga = "+yaris.harga(20) );
                System.out.println("diskon ="+yaris.diskon());
                t = yaris.harga(20) - yaris.diskon();
                System.out.println("total ="+t);
                
            }break;
            default:System.out.println("mobil ndk adoh");
                break;
        }
    }
    
}
