/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Fikri170523;

/**
 *
 * @author User
 */
public class Car {

  
    protected String nomormesin;
    protected String tahunproduksi;
    protected String transmisi;
    protected int kapasitasmesin;
    protected String warnakendaraan;
    public double total;
     public double bayar;
  

    public Car() {
    }

    public Car( String nomormesin, String tahunproduksi, String transmisi, int kapasitasmesin, String warnakendaraan) {
        
        this.nomormesin = nomormesin;
        this.tahunproduksi = tahunproduksi;
        this.transmisi = transmisi;
        this.kapasitasmesin = kapasitasmesin;
        this.warnakendaraan = warnakendaraan;
        
   
        System.out.println("nomor mesein :"+ this.nomormesin);
        System.out.println("tahunproduksi :"+ this.tahunproduksi);
        System.out.println("transmisi :"+ this.transmisi);
        System.out.println("kapasitas :"+ this.kapasitasmesin);
        System.out.println("warna :"+ this.warnakendaraan);
    }

  

    public String getNomormesin() {
        return nomormesin;
    }

    public String getTahunproduksi() {
        return tahunproduksi;
    }

    public String getTransmisi() {
        return transmisi;
    }

    public int getKapasitasmesin() {
        return kapasitasmesin;
    }

    public String getWarnakendaraan() {
        return warnakendaraan;
    }


    public void setNomormesin(String nomormesin) {
        this.nomormesin = nomormesin;
    }

    public void setTahunproduksi(String tahunproduksi) {
        this.tahunproduksi = tahunproduksi;
    }

    public void setTransmisi(String transmisi) {
        this.transmisi = transmisi;
    }

    public void setKapasitasmesin(int kapasitasmesin) {
        this.kapasitasmesin = kapasitasmesin;
    }

    public void setWarnakendaraan(String warnakendaraan) {
        this.warnakendaraan = warnakendaraan;
    }
    
    
    public double harga(double hargaCC){
         
        return total;
    }
    public double diskon(){
        return bayar;
    }
    
    
    
}
