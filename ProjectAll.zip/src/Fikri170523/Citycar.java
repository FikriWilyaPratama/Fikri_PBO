/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Fikri170523;

/**
 *
 * @author User
 */
public class Citycar extends Car {
    public Citycar(){
         super("D0034","2020","manual",3000,"hitam");
    
}
     public double harga(double hargaCC){
         total = kapasitasmesin * hargaCC;
          return total;
    }
     public double diskon(){
         bayar = total * 0.05;
        return bayar;
    }
}
