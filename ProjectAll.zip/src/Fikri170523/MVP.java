/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Fikri170523;

/**
 *
 * @author User
 */
public class MVP extends Car{
    public MVP(){
         super("H0034","2021","matic",8000,"pink");
    
}
     public double harga(double hargaCC){
         total=kapasitasmesin * hargaCC;
          return total;
    }
      public double diskon(){
         bayar = 0 ;
        return bayar;
    }
}
