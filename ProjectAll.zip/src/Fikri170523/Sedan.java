/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Fikri170523;

/**
 *
 * @author User
 */
public class Sedan extends Car {
    public Sedan(){
         super("L0034","2003","matic",2000,"hijau");
        
    }
    
     public double harga(double hargaCC){
         total=kapasitasmesin * hargaCC;
          return total;
    }
      public double diskon(){
         bayar = total * 0.02;
        return bayar;
    }
   
    
}
