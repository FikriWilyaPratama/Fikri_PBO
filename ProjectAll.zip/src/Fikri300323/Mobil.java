/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Fikri300323;

/**
 *
 * @author User
 */
public class Mobil {
    
    String plat ;
    String warna;
    String nomes;
    String trans;
    String pemilik;
    int kecepatan;
    
    double t_kecepatan(int cepat){
       
        kecepatan = cepat + 20;
        System.out.println("kecepatan saat ini.." + kecepatan);
        return kecepatan;
        
        
    }
    
    double perlambat(){
        kecepatan -= 20;
        System.out.println("kecepatan saat ini.." + kecepatan);
        return kecepatan;
        
    }
    
    void berhenti(){
        System.out.println("mobil barantii...");
        
    }
    
}
