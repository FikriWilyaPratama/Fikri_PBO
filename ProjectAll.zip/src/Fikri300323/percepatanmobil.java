package Fikri300323;

public class percepatanmobil {
    public static void main(String[] args) {
        
        Mobil oto = new Mobil();
        
        oto.plat="BB 2342 46";
        oto.trans="manual";
        oto.pemilik="wilyam";
        oto.warna="pink";
        oto.nomes="4537";
        oto.kecepatan=60;
        
        System.out.println("Plat : " + oto.plat);
        System.out.println("Trans : " + oto.trans);
        System.out.println("Pemilik : " + oto.pemilik);
        System.out.println("Warna : " + oto.warna);
        System.out.println("No mesin : " + oto.nomes);
        System.out.println("Kecepatan awal : " + oto.kecepatan);
        System.out.println("Tambah kecepatan : " + oto.t_kecepatan(60));
        oto.perlambat();
        oto.perlambat();
        oto.perlambat();
        oto.berhenti();
        
        
        
        
    }
}
