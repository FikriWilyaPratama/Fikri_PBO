/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Fikri070323;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.InputStreamReader;
        

/**
 *
 * @author User
 */
public class latihan4 {
    public static void main(String[] args) {
        BufferedReader dataIn = new BufferedReader (new InputStreamReader(System.in));
        
        int angka ;
        int angka2 ;
        
        
        System.out.println("Enter your name");
      
        
        try{
             System.out.print("ang 1=");
            angka = (int) Double.parseDouble(dataIn.readLine());
             System.out.print("ang 2=");
            angka2= (int) Double.parseDouble(dataIn.readLine());
            System.out.println(" kali ="+(angka*angka2));     
            System.out.println(" bagi ="+(angka/angka2));     
            System.out.println(" tambah ="+(angka+angka2));     
            System.out.println(" kureng ="+(angka-angka2));     
            System.out.println(" div ="+(angka/angka2));     
            System.out.println(" mod ="+(angka%angka2));     
            }catch ( IOException e ){
                System.out.println("Error!");
            }
         
    }
}

    

