/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Fikri070323;

import javax.swing.*;

public class halaman3 {
    public static void main(String[] args) {
        
       int grade;
        
        grade =Integer.parseInt( JOptionPane.showInputDialog("nilai ="));
          
        
        
        
if( grade > 60 ){ 
JOptionPane.showMessageDialog(null, "congrats"); 
} 
else{ 
 JOptionPane.showMessageDialog(null, "you failded");
} 
    }
}

