/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Fikri070323;

import javax.swing.JOptionPane;

/**
 *
 * @author User
 */
public class halaman10 {
     public static void main(String[] args) {
        
       int grade;
        
        grade =Integer.parseInt( JOptionPane.showInputDialog("nilai ="));
          
        
        
        
switch(grade){ 
 case 100: 
 JOptionPane.showMessageDialog(null, "Exxcellent"); 
 break; 
 case 90: 
 JOptionPane.showMessageDialog(null, "goodjob"); 
 break; 
 case 80: 
 JOptionPane.showMessageDialog(null, "study harder"); 
 break; 
 default: 
 JOptionPane.showMessageDialog(null, "you failed"); 
 } 
 } 
    }
    

