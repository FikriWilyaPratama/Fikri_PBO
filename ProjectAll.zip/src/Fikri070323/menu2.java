/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Fikri070323;

import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author User
 */
public class menu2 {
    public static void main(String[] args) {
        do{
        Scanner angka = new Scanner(System.in);
        
        System.out.println("Pilih Operasi yang Anda inginkan :");
        System.out.println("1. Permutasi");
        System.out.println("2. Kabatakudivmod");
        System.out.println("3. Deret Ascending");
        System.out.println("4. Luas dan keliling lingkaran");
        
        Scanner pilihan = new Scanner(System.in);
        System.out.print("Masukkan Nomor Pilihan = ");
        int menu = pilihan.nextInt();
        switch(menu){
            case 1: ///Permutasi
                System.out.print("Masukkan Angka Pertama : ");
                int n = angka.nextInt();
                System.out.print("Masukkan Angka Kedua : ");
                int r = angka.nextInt();
                
                int a = 1;
                for (int i = 1; i <=n ; i++){
                    a = a* i;}
                
                int b = 1;
                for (int i = 1; i <=n-r ; i++){
                    b = b*i;}
                System.out.print("Hasil Permutasi = " + a/b);
                break;
                
            case 2: ///Kabatakudivmod
                System.out.print("Masukkan Angka Pertama : ");
                double c = angka.nextInt();
                System.out.print("Masukkan Angka Kedua : ");
                double d = angka.nextInt();
                
                System.out.println("Hasil Kali = " + (c*d));
                System.out.println("Hasil Bagi = " + (c/d));
                System.out.println("Hasil Tambah = " + (c+d));
                System.out.println("Hasil Kurang = " + (c-d));
                System.out.println("Hasil Div = " + (c/d));
                System.out.println("Hasil Mod = " + (c%d));
                break;
                
            case 3: ///Deret Ascending
                System.out.print("Masukkan Angka Pertama : ");
                int j = angka.nextInt();
                
                System.out.println("Deret Ascending = ");
                for (int i = 0; i <= j; i ++)
                    System.out.println(i+1);
                break;
            case 4:
                double phi = 3.14;
                System.out.print("Masukkan Jari-Jari Lingkaran : ");
                int jari = angka.nextInt();
                System.out.println("Luas Lingkaran adalah = " + (phi*jari*jari));
                System.out.println("Keliling Lingkaran adalah = " + (phi*jari*2));
                break;
            default:
                System.out.println("Pilihan yang Anda inputkan tidak tersedia.");
                break;
        }   
    }while(JOptionPane.showConfirmDialog(null,"ulang kah?")==JOptionPane.YES_OPTION);
        }
}

