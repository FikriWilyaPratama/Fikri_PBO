/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Fikri070323;

import javax.swing.JOptionPane;

/**
 *
 * @author User
 */
public class halaman7 {
     public static void main(String[] args) {
        
       int grade;
        
        grade =Integer.parseInt( JOptionPane.showInputDialog("angka ="));
          
        
        
        
if(  grade >= 90 ){ 
JOptionPane.showMessageDialog(null, "Exxcellent"); 
} 
else if(  (grade < 90) && (grade >= 80))
{
JOptionPane.showMessageDialog(null, "good job"); 
}
else if(   (grade < 80) && (grade >= 60))
{
JOptionPane.showMessageDialog(null, "study harder"); 
}
else
{ 
 JOptionPane.showMessageDialog(null, "you failded");
} 
    }
    
}
