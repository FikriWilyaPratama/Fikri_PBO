/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Fikri070323;

import javax.swing.*;


public class latihan2 {
    public static void main(String[] args) {
        String name ="";
        String name2 ="";
        String name3 ="";
        name = JOptionPane.showInputDialog("word1 =");
        name2 = JOptionPane.showInputDialog("word2 =");
        name3 = JOptionPane.showInputDialog("word3 =");
        
        String msg = name +" "+ name2+" "+ name3;
        
        JOptionPane.showMessageDialog(null, "Kali = " + msg);
    }
}
