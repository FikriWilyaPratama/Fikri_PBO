/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Fikri070323;

import java.io.IOException;
import java.io.BufferedReader;
import java.io.InputStreamReader;
        

/**
 *
 * @author User
 */
public class latihan1 {
    public static void main(String[] args) {
        BufferedReader dataIn = new BufferedReader (new InputStreamReader(System.in));
        
        String name = "";
        String name2 = "";
        String name3 = "";
        
        System.out.println("Enter your name");
      
        
        try{
             System.out.print("word 1=");
            name = dataIn.readLine();
             System.out.print("word 2=");
            name2 = dataIn.readLine();
             System.out.print("word 3=");
            name3 = dataIn.readLine();
            }catch ( IOException e ){
                System.out.println("Error!");
            }
        System.out.println(name+" "+ name2+" "+ name3);       
    }
}
