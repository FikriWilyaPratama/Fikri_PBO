/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Fikri070323;

import java.util.Scanner;


public class latihan3 {
    public static void main(String[] args) {
        Scanner tt = new Scanner (System.in);
        
        System.out.print("word 1=");
        String nama= tt.nextLine();
         System.out.print("word 2=");
        String nama2= tt.nextLine();
         System.out.print("word 3=");
        String nama3= tt.nextLine();
        
       
        System.out.println(nama+" "+ nama2+" "+ nama3);
        
    }
}
