/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Fikri070323;

import javax.swing.JOptionPane;

/**
 *
 * @author User
 */
public class halaman6 {
    public static void main(String[] args) {
        
       int grade;
        
        grade =Integer.parseInt( JOptionPane.showInputDialog("word1 ="));
          
        
        
        
if( grade > 90 ){ 
JOptionPane.showMessageDialog(null, "Vgood"); 
} 
else if( grade > 60 )
{
JOptionPane.showMessageDialog(null, "Vgood"); 
}
else
{ 
 JOptionPane.showMessageDialog(null, "you failded");
} 
    }
}

    

