/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Fikri070323;

import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author User
 */
public class lanjutan {
    public static void main(String[] args) {
     
		Scanner in = new Scanner(System.in);
		System.out.print("batas nilai = "); int batas = in.nextInt();
		int a=batas;
		char b='A';
		for(int i=0; i<batas; i++) {
			if(i%2 == 0) {
				System.out.print(b++ + " ");
			}
			else {
				System.out.print(a-- + " ");
			}
		}
	}
}
        
            
        
    

