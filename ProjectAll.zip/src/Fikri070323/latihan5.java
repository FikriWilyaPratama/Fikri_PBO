/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Fikri070323;

import javax.swing.*;


public class latihan5 {
    public static void main(String[] args) {
        int name;
        int name2;
        int name3;
        name =Integer.parseInt( JOptionPane.showInputDialog("word1 ="));
        name2 =Integer.parseInt( JOptionPane.showInputDialog("word2 ="));
        name3 = Integer.parseInt(JOptionPane.showInputDialog("word3 ="));
        
        int msg = name + name2 + name3;
        
        JOptionPane.showMessageDialog(null,"kali ="+ msg);
    }
}

