/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Fikri070323;

import java.util.*;



public class latihan6 {
    public static void main(String[] args) {
        Scanner tt = new Scanner (System.in);
        
        System.out.print("ang 1=");
        int nama= tt.nextInt();
         System.out.print("ang 2=");
        int nama2= tt.nextInt();
         System.out.print("ang 3=");
        int nama3= tt.nextInt();
        
       
        System.out.println(nama+ nama2 + nama3);
        
    }
}

