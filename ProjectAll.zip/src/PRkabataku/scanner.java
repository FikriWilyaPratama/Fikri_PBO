/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PRkabataku;

import java.util.*;



public class scanner {
    public static void main(String[] args) {
        Scanner tt = new Scanner (System.in);
        
        System.out.print("ang 1=");
        double nama= tt.nextInt();
         System.out.print("ang 2=");
        double nama2= tt.nextInt();
        
        
       
        System.out.println("kali="+(nama*nama2));
         System.out.println("bagi="+(nama/nama2));
          System.out.println("tambah="+(nama+ nama2));
           System.out.println("kurang="+(nama-nama2));
            System.out.println("div="+(int)(nama/nama2));
             System.out.println("mod="+(nama%nama2));
        
    }
}

