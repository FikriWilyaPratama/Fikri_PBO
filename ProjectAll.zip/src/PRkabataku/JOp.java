/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PRkabataku;

import javax.swing.*;


public class JOp {
    public static void main(String[] args) {
        double name;
        double name2;
      
        name =Integer.parseInt( JOptionPane.showInputDialog("word1 ="));
        name2 =Integer.parseInt( JOptionPane.showInputDialog("word2 ="));
      
        
        double a= name * name2;
        double b = name / name2;
        double c= name + name2;
        double d = name - name2;
        double e= name / name2;
        double f = name % name2;
            
        
        JOptionPane.showMessageDialog(null,"kali="+(int) a);
        JOptionPane.showMessageDialog(null,"bagi="+b);
        JOptionPane.showMessageDialog(null,"tambah="+(int) c);
        JOptionPane.showMessageDialog(null,"kurang="+(int) d);
        JOptionPane.showMessageDialog(null,"div="+(int) e);
        JOptionPane.showMessageDialog(null,"mod="+(int) f);
        
        
    }
}
