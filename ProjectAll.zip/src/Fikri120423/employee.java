/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Fikri120423;

/**
 *
 * @author User
 */
public class employee extends Person {

    public employee() {
         System.out.println("Inside Employee:Constructor");
    
         
    }
    public String getName() {
        System.out.println("Employee name:" + name);
        return name;
    }

 }
    

