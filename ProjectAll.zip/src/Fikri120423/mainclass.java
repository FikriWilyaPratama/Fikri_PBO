/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Fikri120423;

/**
 *
 * @author User
 */
public class mainclass {
    public static void main(String[] args) {

        Person ref;
        Student studentObject = new Student();
        employee employeeObject = new employee();
        
        ref = employeeObject;
        String temp = ref.getName(); 
      
        System.out.println(temp);
        ref = employeeObject; 
 
        System.out.println(temp);

    }
    
    
    
}
