/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Fikri290323;

/**
 *
 * @author User
 */
public class contohmahasiswa {
    public static void main(String[] args) {
        
    mahasiswa mhs = new mahasiswa();
     mahasiswa mhs2 = new mahasiswa();
    
    
    mhs.nama="budi";
    mhs.nim="2201091017";
    mhs.prodi="MI";
    mhs.jurusan="TI";

    
    mhs2.nama="anit";
    mhs2.nim="2201098976";
    mhs2.prodi="MI";
    mhs2.jurusan="TI";
    
        System.out.println("Nama  : "+mhs.nama);
        System.out.println("NIM   : "+mhs.nim);
        System.out.println("prodi : "+mhs.prodi);
        System.out.println("jurusan: "+mhs.jurusan);
        mhs.kelulusan();
        mhs.nilai();
        
         System.out.println("Nama  : "+mhs2.nama);
        System.out.println("NIM   : "+mhs2.nim);
        System.out.println("prodi : "+mhs2.prodi);
        System.out.println("jurusan: "+mhs2.jurusan);
        mhs2.kelulusan();
        mhs2.nilai();
        
    
 
    
}
}
