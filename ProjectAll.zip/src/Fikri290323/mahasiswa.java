/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Fikri290323;

import java.util.Scanner;

public class mahasiswa {
        String nama ;
        String nim;
        String jurusan;
        String prodi;
        int ipk;
        
        
        void nilai()
        {
             Scanner nil = new Scanner(System.in);
             
             int total;
             double rata;
             
             System.out.println("masukkan nilai tugas");
             int tugas = nil.nextInt();
             System.out.println("masukkan nilai uts");
             int uts = nil.nextInt();
             System.out.println("masukkan nilai uas");
             int uas = nil.nextInt();
             
             total= tugas + uts + uas;
             rata= (total)/3;
             System.out.println("total nilai kamu=" + total);
             System.out.println("rata nilai kmu=" + rata);
        }
        
        
     
        void kelulusan(){
             Scanner ip = new Scanner(System.in);
             System.out.println("masukkan ipk anda");
             int ipk = ip.nextInt();
             
            if(ipk >= 3)
            {
                System.out.println("anda lulus");
           
            
            }
            else{
    
            System.out.println("anda tidak lulus");
            }
            
            
        }
        
    
        
}
           
        
        
     
  
        
    
        
    
    

